var vSlow 			= 2.0;
var speedSlow 		= 1.1;
var speed 			= 0.9;
var speedMid 		= 0.4;
var speedAlt 		= 0.2;

var easeIn			= 'Power2.easeOut';
var easeOut			= 'Power2.easeIn';

window.onload = function(){

	"use strict";



	var mainLoop = new TimelineMax({paused:true});

		mainLoop.add("Frame01")
			.set(pizza, {rotation:30, transformOrigin:"50% 50%"})
			//.set(pizza, {scaleX:1.3, scaleY:1.3, transformOrigin:"140px 315px", ease:easeIn})

			.set(lineOne, {autoAlpha:0, scaleX:0.05, transformOrigin:"right"})
			.set(lineTwo, {autoAlpha:0, scaleX:0.05, transformOrigin:"left"})
			.set(lineThree, {autoAlpha:0, scaleX:0.05, transformOrigin:"right"})
			.set(lineFour, {autoAlpha:0, scaleX:0.05, transformOrigin:"left"})
			.set(lineSeven, {autoAlpha:0, scaleX:0.05, transformOrigin:"right"})
			.set(lineEight, {autoAlpha:0, scaleX:0.05, transformOrigin:"left"})

			.set(background, {autoAlpha:1, scaleX:1.0, scaleY:1.0, transformOrigin:"50% 50%"})
			.set(apple, {autoAlpha:1, scaleX:1.3, scaleY:1.3, transformOrigin:"50% 50%"})
			.set(pear2, {autoAlpha:1, scaleX:1.3, scaleY:1.3, transformOrigin:"50% 50%"})
			.set(pear1, {autoAlpha:1, top:450, scaleX:1.3, scaleY:1.3, transformOrigin:"50% 50%"})
			.set(spoon, {autoAlpha:1, scaleX:1.3, scaleY:1.3, transformOrigin:"50% 50%"})
			.set(cinnamon, {autoAlpha:1, scaleX:1.3, scaleY:1.3, transformOrigin:"50% 50%"})

			.set(product, {autoAlpha:0, rotation:-30, scaleX:2.3, scaleY:2.3, transformOrigin:"50% 50%"})

			.to([container,logo], speedMid, {autoAlpha:1}, "Frame01")
      .to(logo, 0.01, {width:128, height:92, top:150, left:835}, "Frame01")

		  .to(pizza, speedSlow, {top:-122, left:-56, scaleX:1.12, scaleY:1.12, rotation:0, transformOrigin:"30% 30%", ease:easeIn}, "Frame01")
			.to(berries, speedSlow, {ease:easeIn}, "Start")

			.to(txt1_01, speedMid, {autoAlpha:1, left:497}, "Frame01+=0.35")
			.to(txt1_01, speedMid, {autoAlpha:1, top:90, left:497}, "Frame01+=1.25")
			.to(txt1_02, speedMid, {autoAlpha:1, left:481}, "Frame01+=1.35")


			.to(lineOne, 1.2, {autoAlpha:1, scaleX:1.0, transformOrigin:"right"}, "Frame01+=1.25")
			.to(lineTwo, 1.2, {autoAlpha:1, scaleX:1.0, transformOrigin:"left"}, "Frame01+=1.25")


		.add("Frame02", 2.9)

		.to(txt1_01, speedMid, {autoAlpha:0}, "Frame02+=0.25")
		.to(txt1_02, speedMid, {autoAlpha:0}, "Frame02+=0.25")
		.to(lineOne, speedMid, {autoAlpha:0}, "Frame02+=0.25")
		.to(lineTwo, speedMid, {autoAlpha:0}, "Frame02+=0.25")
		.to(background, speedSlow, {top:-103, left:-60, scaleX:0.74, scaleY:0.74, transformOrigin:"140px 315px", rotation:0.01, ease:easeIn}, "Frame02+=0.35")
		//.to(pizza, 4, {top:-75, left:-30, scaleX:1.0, scaleY:1.0, transformOrigin:"center left", rotation:0.01, ease:easeIn}, "Frame02+=0.35")
		.to(pizza, speedSlow, {top:-95, left:-131, scaleX:1.0, scaleY:1.0, rotation:0, transformOrigin:"30% 30%", ease:easeIn}, "Frame02+=0.35")
		.to(berries, speedSlow, {top:-56, left:651, scaleX:0.74, scaleY:0.74, rotation:0.-30, ease:easeIn}, "Frame02+=0.35")
		.to(apple, speedSlow, {top:-68, left:798, scaleX:1.0, scaleY:1.0, transformOrigin:"right top", rotation:0.01, ease:easeIn}, "Frame02+=0.35")
		.to(pear1, speedSlow, {autoAlpha:1, top:110, left:589, scaleX:1.0, scaleY:1.0, transformOrigin:"170 top", rotation:0.01, ease:easeIn}, "Frame02+=0.05")
		.to(pear2, speedSlow, {autoAlpha:1, top:-54, left:315, scaleX:1.0, scaleY:1.0, transformOrigin:"170 top", rotation:0.01, ease:easeIn}, "Frame02+=0.35")
		.to(cinnamon, speedSlow, {autoAlpha:1, top:176, left:332, scaleX:1.0, scaleY:1.0, transformOrigin:"right bottom", rotation:0.01, ease:easeIn}, "Frame02+=0.45")
		.to(spoon, 0.75, {autoAlpha:1, top:85, left:731, scaleX:1.0, scaleY:1.0, transformOrigin:"left bottom", rotation:0.01, ease:easeIn}, "Frame02+=0.50")

		.to(txt2_01, speedMid, {autoAlpha:1, left:364}, "Frame02+=1.25")
		.to(txt2_02, speedMid, {autoAlpha:1, left:386}, "Frame02+=1.45")


		.add("Frame03", 6.0)

		.to(txt2_01, speedMid, {autoAlpha:0}, "Frame03+=0.25")
		.to(txt2_02, speedMid, {autoAlpha:0}, "Frame03+=0.25")

		.to(txt3_01, speedMid, {autoAlpha:1, left:465}, "Frame03+=0.75")
		.to(txt3_02, speedMid, {autoAlpha:1, left:410}, "Frame03+=0.95")
		.to(txt3_03, speedMid, {autoAlpha:1, left:488}, "Frame03+=1.15")
		.to(txt3_04, speedMid, {autoAlpha:1, left:421}, "Frame03+=1.35")
		.to(lineThree, 1.2, {autoAlpha:1, scaleX:1.0, transformOrigin:"right"}, "Frame03+=0.95")
		.to(lineFour, 1.2, {autoAlpha:1, scaleX:1.0, transformOrigin:"left"}, "Frame03+=0.95")


		.add("Frame04", 9.0)

		.to(txt3_01, 1.1, {autoAlpha:0, top:16, left:621}, "Frame04+=0.25")
		.to(txt3_02, 1.1, {autoAlpha:1, top:35, left:569}, "Frame04+=0.25")
		.to(txt3_03, 1.1, {autoAlpha:1, top:79, left:647}, "Frame04+=0.25")
		.to(txt3_04, 1.1, {autoAlpha:1, top:110, left:580}, "Frame04+=0.25")
		.to(lineThree, 1.1, {autoAlpha:0, top:21, left:568}, "Frame04+=0.25")
		.to(lineFour, 1.1, {autoAlpha:0, top:21, left:760}, "Frame04+=0.25")

		.to(pear1, 1.1, {autoAlpha:1, top:450, left:389, scaleX:1.0, scaleY:1.0, transformOrigin:"-70 top", rotation:0.01, ease:easeIn}, "Frame04+=0.35")
		.to(pear2, 1.1, {autoAlpha:1, top:-158, left:265, scaleX:1.0, scaleY:1.0, transformOrigin:"-70 top", rotation:0.01, ease:easeIn}, "Frame04+=0.35")
		.to(berries, 1.1, {top:-256, left:751, scaleX:0.74, scaleY:0.74, transformOrigin:"left top", rotation:0.01, ease:easeIn}, "Frame04+=0.35")
		.to(apple, 1.1, {top:-58, left:1123, scaleX:1.0, scaleY:1.0, transformOrigin:"right top", rotation:0.01, ease:easeIn}, "Frame04+=0.35")
		.to(spoon, 0.9, {autoAlpha:1, top:250, left:721, scaleX:1.0, scaleY:1.0, transformOrigin:"right bottom", rotation:0.01, ease:easeIn}, "Frame04+=0.35")
		.to(pizza, 1.1, {top:-35, left:-490, scaleX:1.0, scaleY:1.0, transformOrigin:"140px 315px", rotation:0.01, ease:easeIn}, "Frame04+=0.35")
		.to(cinnamon, 1.1, {autoAlpha:1, top:283, left:336, scaleX:1.0, scaleY:1.0, transformOrigin:"right bottom", rotation:0.01, ease:easeIn}, "Frame04+=0.35")

		.to([berries,spoon,pear2], 0, {autoAlpha:0}, "Frame04+=1.35")



		.add("Frame05", 10.2)

    .to(pear1, 0, {autoAlpha:0, top:450, left:25, scaleX:1.0, scaleY:1.0, transformOrigin:"-70 top", rotation:-52, ease:easeIn}, "Frame05-=0.2")
		.to(apple, 0, {autoAlpha:0, top:-250, left:-88, scaleX:1.0, scaleY:1.0, transformOrigin:"right top", rotation:-15, ease:easeIn}, "Frame05+=0.2")
		.to(berries, 0, {autoAlpha:0, top:450, left:521, scaleX:0.74, scaleY:0.74, transformOrigin:"left top", rotation:44, ease:easeIn}, "Frame05-=0.2")
		.to(cinnamon, 0, {autoAlpha:0, top:270, left:116, scaleX:1.0, scaleY:1.0, transformOrigin:"right bottom", rotation:0.01, ease:easeIn}, "Frame05-=0.2")

		.to(product, 0.01, {autoAlpha:1}, "Frame05+=0.75")
		.to(product, 0.7, {autoAlpha:1, top:-27, left:157, scaleX:1.0, scaleY:1.0, transformOrigin:"bottom right", rotation:0.01, ease:easeIn}, "Frame05-=0.40")

		.to(pear1, 0.7, {autoAlpha:1, top:115, left:-21, scaleX:1.0, scaleY:1.0, transformOrigin:"-15 top", rotation:-52, ease:easeIn}, "Frame05+=0.30")
		.to(apple, 0.7, {autoAlpha:1, top:-91, left:-16, scaleX:1.0, scaleY:1.0, transformOrigin:"right top", rotation:-15, ease:easeIn}, "Frame05+=0.30")
		.to(berries, 0.7, {autoAlpha:1, top:131, left:481, scaleX:0.74, scaleY:0.74, transformOrigin:"left top", rotation:44, ease:easeIn}, "Frame05+=0.35")
		.to(cinnamon, 0.7, {autoAlpha:1, top:93, left:69, scaleX:0.85, scaleY:0.85, transformOrigin:"right bottom", rotation:0.01, ease:easeIn}, "Frame05+=0.40")

		.to(txt4_01, speedMid, {autoAlpha:1, top:158, left:603}, "Frame05+=0.30")
		.to(lineSeven, 1.1, {autoAlpha:1, scaleX:1.0, transformOrigin:"right"}, "Frame05+=0.40")
		.to(lineEight, 1.1, {autoAlpha:1, scaleX:1.0, transformOrigin:"left"}, "Frame05+=0.40")

		.to(cta, speedAlt, {autoAlpha:1}, "Frame05+=1.60")
		.add(ctaPulse, "Frame05+=2.0")
		.add(addCtaListeners, "Frame05+=4.3");



	function ctaPulse() {
		TweenMax.to(overlay, speedAlt, {autoAlpha:1});
		TweenMax.to(overlay, speedAlt, {autoAlpha:0, delay:speedAlt-0.1});
	}
	function ctaOver() { TweenMax.to(overlay, speedAlt, {autoAlpha:1}); }
	function ctaOut() { TweenMax.to(overlay, speedAlt, {autoAlpha:0}); }


	function is_touch_device() {
	 return (('ontouchstart' in window)
		  || (navigator.MaxTouchPoints > 0)
		  || (navigator.msMaxTouchPoints > 0));
	}

	function addCtaListeners() {
		if (!is_touch_device()) {
			backgroundExit.addEventListener('mouseover', ctaOver);
			backgroundExit.addEventListener('mouseout', ctaOut);
		}
	}
	function addListeners() {
		backgroundExit.addEventListener('click', staticEndFrame);
		myFT.applyClickTag( backgroundExit, 1 );
	}

	function staticEndFrame() {
		mainLoop.totalProgress(1);
	}

	function initialProps() {


		addListeners();
		mainLoop.play();

	}

	initialProps();


};
