FT.manifest({
	"filename":"index.html",
	"width":970,
	"height":250,
	"clickTagCount":1,
	"hideBrowsers":["ie9", "android4.3", "iOS5", "safari5.1"],
	"richLoads": [{
		"name": "sRichload",
		"src": "ms_times_healthy_food_dessert_970x250_richload"
	}]
});
